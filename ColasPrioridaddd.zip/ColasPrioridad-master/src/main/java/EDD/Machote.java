/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDD;

/**
 *
 * @author Danchita45
 */
public interface Machote {
    public boolean vacio();
        
    public boolean llena ();
    public boolean inserta(Object obj);
    public Object elimina();
    
}
